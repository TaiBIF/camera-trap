#!/usr/bin/env python3
from hachoir.metadata.main import main
main()
