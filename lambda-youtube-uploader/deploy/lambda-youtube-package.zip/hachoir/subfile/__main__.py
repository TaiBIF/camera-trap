#!/usr/bin/env python3
from hachoir.subfile.main import main
main()
