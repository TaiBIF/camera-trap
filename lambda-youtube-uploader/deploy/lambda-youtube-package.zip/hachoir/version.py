PACKAGE = "hachoir"
VERSION = "3.0a3"
WEBSITE = 'http://hachoir.readthedocs.io/'
LICENSE = 'GNU GPL v2'
