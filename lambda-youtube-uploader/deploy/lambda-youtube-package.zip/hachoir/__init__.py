from hachoir.version import VERSION as __version__   # noqa
